import React from 'react';
import './App.css';
import Main from "./components/Main"
import "bootstrap/dist/css/bootstrap.min.css";



function App() {
  return (
      <div className="App">
        <h1>Favorite Author</h1>
        <Main />
      </div>
  );
}

export default App;